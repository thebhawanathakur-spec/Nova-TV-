NOVA TV - Starter Android TV Launcher

Yeh starter project Android TV launcher ke liye hai.
Features:
- Android TV / Leanback launcher entry
- Installed TV + regular launcher apps ki list
- Apps launch
- D-pad focus navigation and OK selection (Compose focus)
- Quick accent colour selection
- Refresh apps

APK yahan directly compile nahi ho saka kyunki is environment mein Android SDK/Gradle installed nahi hain.
Cloud build workflow included hai:
1. ZIP extract karein.
2. GitHub par naya repository banayein aur files upload karein.
3. Repository ke Actions tab mein "Build Nova TV APK" workflow select karein.
4. Run workflow click karein.
5. Build complete hone par "Nova-TV-APK" artifact download karein.
6. APK ko USB / cloud drive se TV par transfer karke install karein.

Note: Android TV settings mein unknown apps installation allow karni pad sakti hai.
Launcher ko Home default banane ke liye Home button dabakar system chooser se Nova TV select karein, agar TV chooser dikhaye.
