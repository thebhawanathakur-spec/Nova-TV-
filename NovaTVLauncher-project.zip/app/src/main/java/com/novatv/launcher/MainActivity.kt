package com.novatv.launcher

import android.content.Intent
import android.os.Bundle
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged\nimport androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class TvApp(val label: String, val packageName: String)

class MainActivity : ComponentActivity() {
    private fun loadApps(): List<TvApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val tvApps = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { TvApp(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
        val regular = packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), PackageManager.MATCH_ALL
        ).map { TvApp(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
        return (tvApps + regular).distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var apps by remember { mutableStateOf(loadApps()) }
            var showSettings by remember { mutableStateOf(false) }
            var accent by remember { mutableStateOf(0) }
            val accents = listOf(Color(0xFF7C5CFF), Color(0xFF00B8D9), Color(0xFFFF7A45), Color(0xFF54C77A))
            val bg = Brush.linearGradient(listOf(Color(0xFF101322), Color(0xFF171B30), Color(0xFF090B12)))
            MaterialTheme(colorScheme = darkColorScheme(primary = accents[accent])) {
                Box(Modifier.fillMaxSize().background(bg).padding(horizontal = 42.dp, vertical = 28.dp)) {
                    Column(Modifier.fillMaxSize()) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.weight(1f)) {
                                Text("NOVA", color = accents[accent], fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
                                Text("TV", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                            }
                            Button(onClick = { showSettings = !showSettings }) { Text(if (showSettings) "Close settings" else "Customize") }
                            Spacer(Modifier.width(12.dp))
                            OutlinedButton(onClick = { apps = loadApps() }) { Text("Refresh apps") }
                        }
                        Spacer(Modifier.height(20.dp))
                        Text(if (showSettings) "Quick customization" else "Your apps", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(16.dp))
                        if (showSettings) {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xCC20243A)), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                    Text("Accent colour", color = Color.White, fontSize = 18.sp)
                                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        accents.forEachIndexed { index, color ->
                                            Button(onClick = { accent = index }, colors = ButtonDefaults.buttonColors(containerColor = color)) {
                                                Text(if (accent == index) "Selected" else "Choose")
                                            }
                                        }
                                    }
                                    Text("Nova TV starter • App grid • Remote navigation • Accent colours", color = Color.LightGray)
                                }
                            }
                        } else {
                            LazyVerticalGrid(columns = GridCells.Adaptive(minSize = 150.dp), contentPadding = PaddingValues(bottom = 24.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                items(apps, key = { it.packageName }) { app ->
                                    AppTile(app = app, accent = accents[accent]) {
                                        val launch = packageManager.getLaunchIntentForPackage(app.packageName)
                                        if (launch != null) startActivity(launch)
                                    }
                                }
                            }
                        }
                    }
                    Text("NOVATV  •  Customize your screen", color = Color(0xFF8790AC), fontSize = 12.sp, modifier = Modifier.align(Alignment.BottomEnd))
                }
            }
        }
    }
}

@Composable
fun AppTile(app: TvApp, accent: Color, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = if (focused) accent.copy(alpha = 0.24f) else Color(0xAA20243A),
        border = if (focused) androidx.compose.foundation.BorderStroke(2.dp, accent) else null,
        modifier = Modifier.height(105.dp).onFocusChanged { focused = it.isFocused }.focusable()
    ) {
        Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
            Text(app.label, color = Color.White, fontSize = 18.sp, fontWeight = if (focused) FontWeight.Bold else FontWeight.Medium)
        }
    }
}
